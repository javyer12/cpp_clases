#include <iostream>
using namespace std;
int main()
{
    cout << 3 * 3 << "\n";
    cout << "Hello world" << "\n";
    cout << "from vsc and c++";
    return 0;
}